/**
 * hello
 */
public class hello {

    public static void main(String[]agrs)
    {
        System.out.println("Hello world");
    }
}