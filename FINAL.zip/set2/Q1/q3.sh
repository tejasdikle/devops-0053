# Create a file named 'abc.txt'
echo "This is the content of abc.txt" > abc.txt

# Find files with the name 'abc.txt' in the current directory and its subdirectories
if find . -name "abc.txt" ; then
    echo "--------------------------"
    echo "File is found."
    echo "--------------------------"

else
    echo "--------------------------"
    echo "File not found."
    echo "--------------------------"

fi
