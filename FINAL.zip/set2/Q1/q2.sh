#!/bin/bash

# Create 'cdac.txt' and write 5 lines
echo "Java is great" > cdac.txt
echo "Scripting is easy" >> cdac.txt
echo "I love Java" >> cdac.txt
echo "Python is good, too" >> cdac.txt
echo "Hello, Java World!" >> cdac.txt

# Count lines that do not contain the word "Java"
non_java_lines=$(grep -c -v "Java" cdac.txt)
echo "--------------------------------------"
echo "Number of lines not containing 'Java': $non_java_lines"
echo "--------------------------------------"